import type { Emotion } from '../App';
import { TrendingUp, Activity } from 'lucide-react';

interface EmotionStatsProps {
  currentEmotion: Emotion;
  emotionHistory: { emotion: Emotion; timestamp: Date }[];
}

export function EmotionStats({ currentEmotion, emotionHistory }: EmotionStatsProps) {
  const emotionColors: Record<Emotion, string> = {
    happy: 'from-yellow-400 to-orange-400',
    sad: 'from-blue-400 to-indigo-400',
    angry: 'from-red-500 to-pink-500',
    calm: 'from-green-400 to-teal-400',
    neutral: 'from-gray-400 to-slate-400',
    surprised: 'from-purple-400 to-pink-400',
    fearful: 'from-indigo-500 to-purple-600',
  };

  const emotionEmojis: Record<Emotion, string> = {
    happy: '😊',
    sad: '😢',
    angry: '😠',
    calm: '😌',
    neutral: '😐',
    surprised: '😮',
    fearful: '😰',
  };

  // Calculate emotion distribution
  const emotionCounts: Record<Emotion, number> = {
    happy: 0,
    sad: 0,
    angry: 0,
    calm: 0,
    neutral: 0,
    surprised: 0,
    fearful: 0,
  };

  emotionHistory.forEach(({ emotion }) => {
    emotionCounts[emotion]++;
  });

  const maxCount = Math.max(...Object.values(emotionCounts), 1);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-2xl">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Activity className="w-7 h-7" /> Emotion Analytics
      </h2>

      <div className="space-y-6">
        {/* Current Emotion Card */}
        <div className={`bg-gradient-to-r ${emotionColors[currentEmotion]} rounded-xl p-6 text-center shadow-lg`}>
          <div className="text-6xl mb-2">{emotionEmojis[currentEmotion]}</div>
          <h3 className="text-2xl font-bold capitalize text-white">{currentEmotion}</h3>
          <p className="text-white/90 text-sm mt-1">Current Emotional State</p>
        </div>

        {/* Emotion Distribution */}
        {emotionHistory.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-purple-200">
              <TrendingUp className="w-4 h-4" />
              <span>Recent Emotion Distribution</span>
            </div>

            {Object.entries(emotionCounts).map(([emotion, count]) => {
              const percentage = (count / emotionHistory.length) * 100;
              const barWidth = (count / maxCount) * 100;

              if (count === 0) return null;

              return (
                <div key={emotion} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 capitalize">
                      <span>{emotionEmojis[emotion as Emotion]}</span>
                      {emotion}
                    </span>
                    <span className="text-purple-300">{percentage.toFixed(0)}%</span>
                  </div>
                  <div className="bg-white/10 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${emotionColors[emotion as Emotion]} transition-all duration-500`}
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {emotionHistory.length === 0 && (
          <div className="text-center py-8 text-purple-300">
            <div className="text-4xl mb-2">📊</div>
            <p>No emotion data yet. Start detecting to see your emotional analytics!</p>
          </div>
        )}

        {/* Session Info */}
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-purple-300">{emotionHistory.length}</div>
              <div className="text-xs text-purple-200">Detections</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-300">
                {Object.keys(emotionCounts).filter(k => emotionCounts[k as Emotion] > 0).length}
              </div>
              <div className="text-xs text-purple-200">Emotions Felt</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
