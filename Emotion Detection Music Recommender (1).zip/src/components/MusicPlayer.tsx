import { useEffect, useState } from 'react';
import type { Song } from '../App';

interface MusicPlayerProps {
  song: Song;
}

export function MusicPlayer({ song }: MusicPlayerProps) {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    setIsReady(false);
    // Small delay for smooth transition
    const timer = setTimeout(() => setIsReady(true), 100);
    return () => clearTimeout(timer);
  }, [song.youtubeId]);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-2xl">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        🎵 Now Playing
      </h2>

      <div className="space-y-4">
        {/* Song Info */}
        <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-4 border border-purple-500/30">
          <h3 className="text-xl font-bold mb-1">{song.title}</h3>
          <p className="text-purple-200">{song.artist}</p>
        </div>

        {/* YouTube Embed */}
        <div className="relative rounded-2xl overflow-hidden aspect-video bg-black/30">
          {isReady ? (
            <iframe
              src={`https://www.youtube.com/embed/${song.youtubeId}?autoplay=1&rel=0`}
              title={song.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
        </div>

        {/* Player Info */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
          <p className="text-sm text-blue-200">
            🎧 Music powered by YouTube. Volume controls are in the video player.
          </p>
        </div>
      </div>
    </div>
  );
}
