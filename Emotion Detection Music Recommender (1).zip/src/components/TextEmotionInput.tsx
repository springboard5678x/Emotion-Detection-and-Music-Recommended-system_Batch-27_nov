import { useState } from 'react';
import type { Emotion } from '../App';
import { Sparkles } from 'lucide-react';

interface TextEmotionInputProps {
  onEmotionDetected: (emotion: Emotion) => void;
}

export function TextEmotionInput({ onEmotionDetected }: TextEmotionInputProps) {
  const [text, setText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<{ emotion: Emotion; confidence: number } | null>(null);

  const analyzeText = () => {
    if (!text.trim()) return;

    setAnalyzing(true);

    // Simulate AI processing delay
    setTimeout(() => {
      const emotion = detectEmotionFromText(text);
      const confidence = 75 + Math.random() * 20;

      setResult({ emotion, confidence: Math.round(confidence) });
      onEmotionDetected(emotion);
      setAnalyzing(false);
    }, 1500);
  };

  const detectEmotionFromText = (inputText: string): Emotion => {
    const lowerText = inputText.toLowerCase();

    // Emotion keywords mapping
    const emotionKeywords: Record<Emotion, string[]> = {
      happy: ['happy', 'joy', 'excited', 'amazing', 'wonderful', 'great', 'love', 'blessed', 'fantastic', 'awesome', 'delighted', 'cheerful', '😊', '😄', '🎉', '❤️'],
      sad: ['sad', 'unhappy', 'depressed', 'down', 'crying', 'tears', 'heartbroken', 'lonely', 'miserable', 'disappointed', '😢', '😭', '💔'],
      angry: ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'rage', 'hate', 'irritated', 'pissed', '😠', '😡', '🤬'],
      calm: ['calm', 'peaceful', 'relaxed', 'serene', 'tranquil', 'quiet', 'meditation', 'zen', 'chill', 'comfortable', '😌', '🧘'],
      fearful: ['scared', 'afraid', 'fear', 'anxious', 'worried', 'nervous', 'terrified', 'panic', 'stress', '😰', '😨'],
      surprised: ['surprised', 'shocked', 'amazed', 'wow', 'unexpected', 'astonished', 'stunned', '😮', '😲', '🤯'],
      neutral: [],
    };

    // Count matches for each emotion
    const scores: Record<Emotion, number> = {
      happy: 0,
      sad: 0,
      angry: 0,
      calm: 0,
      fearful: 0,
      surprised: 0,
      neutral: 0,
    };

    for (const [emotion, keywords] of Object.entries(emotionKeywords) as [Emotion, string[]][]) {
      for (const keyword of keywords) {
        if (lowerText.includes(keyword)) {
          scores[emotion]++;
        }
      }
    }

    // Find emotion with highest score
    let maxScore = 0;
    let detectedEmotion: Emotion = 'neutral';

    for (const [emotion, score] of Object.entries(scores) as [Emotion, number][]) {
      if (score > maxScore) {
        maxScore = score;
        detectedEmotion = emotion;
      }
    }

    // Check for punctuation patterns
    if (lowerText.includes('!!!') || lowerText.includes('?!')) {
      detectedEmotion = maxScore > 0 ? detectedEmotion : 'surprised';
    }

    return detectedEmotion;
  };

  const exampleTexts = [
    "I'm feeling so happy and energetic today! 😊",
    "I'm really stressed and worried about everything...",
    "This is so frustrating! I can't take it anymore!",
    "Just relaxing and enjoying the peaceful evening.",
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-2xl">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Sparkles className="w-7 h-7" /> Text Emotion Analysis
      </h2>

      <div className="space-y-4">
        {/* Text Input */}
        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type or paste your text here to analyze your emotions..."
            className="w-full h-40 bg-white/10 border border-white/20 rounded-xl p-4 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            disabled={analyzing}
          />
          {text.length > 0 && (
            <div className="absolute bottom-2 right-2 text-xs text-purple-300">
              {text.length} characters
            </div>
          )}
        </div>

        {/* Analyze Button */}
        <button
          onClick={analyzeText}
          disabled={!text.trim() || analyzing}
          className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-300 ${
            !text.trim() || analyzing
              ? 'bg-gray-500/30 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-lg hover:shadow-purple-500/50 hover:scale-105'
          }`}
        >
          {analyzing ? (
            <span className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Analyzing...
            </span>
          ) : (
            '🔍 Analyze Emotion'
          )}
        </button>

        {/* Result */}
        {result && (
          <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/50 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-purple-200">Detected Emotion:</span>
              <span className="text-sm text-purple-300">{result.confidence}% confident</span>
            </div>
            <div className="text-2xl font-bold capitalize flex items-center gap-2">
              {result.emotion}
              {result.emotion === 'happy' && '😊'}
              {result.emotion === 'sad' && '😢'}
              {result.emotion === 'angry' && '😠'}
              {result.emotion === 'calm' && '😌'}
              {result.emotion === 'fearful' && '😰'}
              {result.emotion === 'surprised' && '😮'}
              {result.emotion === 'neutral' && '😐'}
            </div>
          </div>
        )}

        {/* Example Texts */}
        <div className="space-y-2">
          <p className="text-sm text-purple-200 font-semibold">Try these examples:</p>
          <div className="space-y-2">
            {exampleTexts.map((example, index) => (
              <button
                key={index}
                onClick={() => setText(example)}
                className="w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg p-3 text-sm transition-all duration-200 hover:scale-102"
              >
                {example}
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
          <p className="text-sm text-blue-200">
            💡 <strong>Tip:</strong> The AI analyzes your text for emotional content using natural language processing. Try using emojis for better accuracy!
          </p>
        </div>
      </div>
    </div>
  );
}
