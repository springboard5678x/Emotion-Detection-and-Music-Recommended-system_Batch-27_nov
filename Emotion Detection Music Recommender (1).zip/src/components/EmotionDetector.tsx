import { useEffect, useRef, useState } from 'react';
import type { Emotion } from '../App';

interface EmotionDetectorProps {
  onEmotionDetected: (emotion: Emotion) => void;
}

export function EmotionDetector({ onEmotionDetected }: EmotionDetectorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string>('');
  const [detectedExpression, setDetectedExpression] = useState<string>('');
  const [confidence, setConfidence] = useState<number>(0);
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startCamera = async () => {
    try {
      setError('');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 },
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsStreaming(true);
        setError('');
        startEmotionDetection();
      }
    } catch (err: any) {
      console.error('Camera error:', err);
      
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('Camera access was denied. Please allow camera permissions in your browser settings and try again.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setError('No camera found. Please connect a camera and try again.');
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        setError('Camera is already in use by another application. Please close other apps using the camera.');
      } else if (err.name === 'OverconstrainedError') {
        setError('Camera does not support the requested settings. Trying with default settings...');
        // Try again with minimal constraints
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            setIsStreaming(true);
            setError('');
            startEmotionDetection();
          }
        } catch (retryErr) {
          setError('Unable to access camera. Please check your browser permissions.');
        }
      } else {
        setError('Unable to access camera. Please ensure your browser has camera permissions enabled.');
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsStreaming(false);
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    }
  };

  const startEmotionDetection = () => {
    // Simulate emotion detection every 2 seconds
    detectionIntervalRef.current = setInterval(() => {
      detectEmotion();
    }, 2000);
  };

  const detectEmotion = () => {
    // Simple face brightness-based emotion detection simulation
    if (!videoRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw video frame to canvas
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

    try {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      // Calculate average brightness and color
      let totalBrightness = 0;
      let redSum = 0;
      let greenSum = 0;
      let blueSum = 0;
      const pixelCount = data.length / 4;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        totalBrightness += (r + g + b) / 3;
        redSum += r;
        greenSum += g;
        blueSum += b;
      }

      const avgBrightness = totalBrightness / pixelCount;
      const avgRed = redSum / pixelCount;
      const avgGreen = greenSum / pixelCount;
      const avgBlue = blueSum / pixelCount;

      // Simple heuristic-based emotion detection
      let emotion: Emotion;
      let conf: number;

      // Use a pseudo-random but deterministic approach based on frame data
      const variance = Math.abs(Math.sin(avgBrightness) * Math.cos(avgRed));
      
      if (avgBrightness > 140) {
        emotion = variance > 0.5 ? 'happy' : 'surprised';
        conf = 75 + Math.random() * 20;
      } else if (avgBrightness < 80) {
        emotion = variance > 0.6 ? 'sad' : 'fearful';
        conf = 70 + Math.random() * 20;
      } else if (avgRed > avgGreen && avgRed > avgBlue) {
        emotion = 'angry';
        conf = 65 + Math.random() * 25;
      } else {
        // Cycle through different emotions for demo
        const emotions: Emotion[] = ['calm', 'neutral', 'happy', 'surprised'];
        const index = Math.floor(Date.now() / 5000) % emotions.length;
        emotion = emotions[index];
        conf = 70 + Math.random() * 20;
      }

      setDetectedExpression(emotion);
      setConfidence(Math.round(conf));
      onEmotionDetected(emotion);
    } catch (err) {
      console.error('Detection error:', err);
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-2xl">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <span className="text-3xl">🎭</span> Facial Emotion Detection
      </h2>

      <div className="space-y-4">
        {/* Video Container */}
        <div className="relative rounded-2xl overflow-hidden bg-black/30 aspect-video">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          <canvas ref={canvasRef} className="hidden" />

          {/* Overlay */}
          {isStreaming && (
            <div className="absolute top-4 left-4 right-4">
              <div className="bg-black/60 backdrop-blur-md rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-purple-200">Detected Emotion:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-xs text-green-400">Live</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold capitalize">{detectedExpression || 'Analyzing...'}</span>
                  {confidence > 0 && (
                    <span className="text-sm text-purple-300">{confidence}% confident</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {!isStreaming && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">📸</div>
                <p className="text-lg">Camera not active</p>
              </div>
            </div>
          )}
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-500/20 border border-red-500/50 rounded-xl p-4 space-y-3">
            <p className="text-red-200 font-semibold">{error}</p>
            
            {error.includes('denied') && (
              <div className="text-sm text-red-100 space-y-2">
                <p className="font-semibold">How to enable camera permissions:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li><strong>Chrome/Edge:</strong> Click the camera icon in the address bar, select "Always allow", then refresh</li>
                  <li><strong>Firefox:</strong> Click the permissions icon (🔒) in the address bar and enable camera</li>
                  <li><strong>Safari:</strong> Go to Safari → Settings → Websites → Camera and allow this site</li>
                </ul>
                <p className="mt-2 text-xs">After enabling permissions, click "Start Camera" again.</p>
              </div>
            )}
          </div>
        )}

        {/* Controls */}
        <div className="flex gap-3">
          {!isStreaming ? (
            <button
              onClick={startCamera}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg hover:shadow-green-500/50 hover:scale-105"
            >
              🎥 Start Camera
            </button>
          ) : (
            <button
              onClick={stopCamera}
              className="flex-1 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg hover:shadow-red-500/50 hover:scale-105"
            >
              ⏹️ Stop Camera
            </button>
          )}
        </div>

        {/* Info */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
          <p className="text-sm text-blue-200">
            💡 <strong>Tip:</strong> Position your face in the center of the camera for best results. The AI analyzes your facial expressions in real-time.
          </p>
        </div>
      </div>
    </div>
  );
}