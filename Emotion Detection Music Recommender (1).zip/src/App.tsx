import { useState } from 'react';
import { EmotionDetector } from './components/EmotionDetector';
import { MusicPlayer } from './components/MusicPlayer';
import { TextEmotionInput } from './components/TextEmotionInput';
import { EmotionStats } from './components/EmotionStats';

export interface Song {
  id: string;
  title: string;
  artist: string;
  youtubeId: string;
  emotion: string;
  thumbnail: string;
}

export type Emotion = 'happy' | 'sad' | 'angry' | 'neutral' | 'surprised' | 'fearful' | 'calm';

export default function App() {
  const [detectedEmotion, setDetectedEmotion] = useState<Emotion>('neutral');
  const [recommendedSongs, setRecommendedSongs] = useState<Song[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [detectionMode, setDetectionMode] = useState<'camera' | 'text'>('camera');
  const [emotionHistory, setEmotionHistory] = useState<{ emotion: Emotion; timestamp: Date }[]>([]);

  const handleEmotionDetected = (emotion: Emotion) => {
    setDetectedEmotion(emotion);
    setEmotionHistory(prev => [...prev, { emotion, timestamp: new Date() }].slice(-10));
    
    // Get recommendations based on emotion
    const songs = getRecommendations(emotion);
    setRecommendedSongs(songs);
    
    // Auto-play first song if none is playing
    if (!currentSong && songs.length > 0) {
      setCurrentSong(songs[0]);
    }
  };

  const getRecommendations = (emotion: Emotion): Song[] => {
    const musicDatabase: Record<Emotion, Song[]> = {
      happy: [
        { id: '1', title: 'Happy', artist: 'Pharrell Williams', youtubeId: 'ZbZSe6N_BXs', emotion: 'happy', thumbnail: 'https://img.youtube.com/vi/ZbZSe6N_BXs/mqdefault.jpg' },
        { id: '2', title: 'Can\'t Stop the Feeling', artist: 'Justin Timberlake', youtubeId: 'ru0K8uYEZWw', emotion: 'happy', thumbnail: 'https://img.youtube.com/vi/ru0K8uYEZWw/mqdefault.jpg' },
        { id: '3', title: 'Walking on Sunshine', artist: 'Katrina and the Waves', youtubeId: 'iPUmE-tne5U', emotion: 'happy', thumbnail: 'https://img.youtube.com/vi/iPUmE-tne5U/mqdefault.jpg' },
        { id: '4', title: 'Don\'t Stop Me Now', artist: 'Queen', youtubeId: 'HgzGwKwLmgM', emotion: 'happy', thumbnail: 'https://img.youtube.com/vi/HgzGwKwLmgM/mqdefault.jpg' },
      ],
      sad: [
        { id: '5', title: 'Someone Like You', artist: 'Adele', youtubeId: 'hLQl3WQQoQ0', emotion: 'sad', thumbnail: 'https://img.youtube.com/vi/hLQl3WQQoQ0/mqdefault.jpg' },
        { id: '6', title: 'Fix You', artist: 'Coldplay', youtubeId: 'k4V3Mo61fJM', emotion: 'sad', thumbnail: 'https://img.youtube.com/vi/k4V3Mo61fJM/mqdefault.jpg' },
        { id: '7', title: 'The Scientist', artist: 'Coldplay', youtubeId: 'RB-RcX5DS5A', emotion: 'sad', thumbnail: 'https://img.youtube.com/vi/RB-RcX5DS5A/mqdefault.jpg' },
        { id: '8', title: 'Skinny Love', artist: 'Bon Iver', youtubeId: 'ssdgFoHLwnk', emotion: 'sad', thumbnail: 'https://img.youtube.com/vi/ssdgFoHLwnk/mqdefault.jpg' },
      ],
      angry: [
        { id: '9', title: 'In the End', artist: 'Linkin Park', youtubeId: 'eVTXPUF4Oz4', emotion: 'angry', thumbnail: 'https://img.youtube.com/vi/eVTXPUF4Oz4/mqdefault.jpg' },
        { id: '10', title: 'Numb', artist: 'Linkin Park', youtubeId: 'kXYiU_JCYtU', emotion: 'angry', thumbnail: 'https://img.youtube.com/vi/kXYiU_JCYtU/mqdefault.jpg' },
        { id: '11', title: 'Break Stuff', artist: 'Limp Bizkit', youtubeId: 'ZpUYjpKg9KY', emotion: 'angry', thumbnail: 'https://img.youtube.com/vi/ZpUYjpKg9KY/mqdefault.jpg' },
        { id: '12', title: 'Smells Like Teen Spirit', artist: 'Nirvana', youtubeId: 'hTWKbfoikeg', emotion: 'angry', thumbnail: 'https://img.youtube.com/vi/hTWKbfoikeg/mqdefault.jpg' },
      ],
      calm: [
        { id: '13', title: 'Weightless', artist: 'Marconi Union', youtubeId: 'UfcAVejslrU', emotion: 'calm', thumbnail: 'https://img.youtube.com/vi/UfcAVejslrU/mqdefault.jpg' },
        { id: '14', title: 'Clair de Lune', artist: 'Debussy', youtubeId: 'CvFH_6DNRCY', emotion: 'calm', thumbnail: 'https://img.youtube.com/vi/CvFH_6DNRCY/mqdefault.jpg' },
        { id: '15', title: 'Gymnopédie No.1', artist: 'Erik Satie', youtubeId: 'S-Xm7s9eGxU', emotion: 'calm', thumbnail: 'https://img.youtube.com/vi/S-Xm7s9eGxU/mqdefault.jpg' },
        { id: '16', title: 'River Flows in You', artist: 'Yiruma', youtubeId: '7maJOI3QMu0', emotion: 'calm', thumbnail: 'https://img.youtube.com/vi/7maJOI3QMu0/mqdefault.jpg' },
      ],
      neutral: [
        { id: '17', title: 'Shape of You', artist: 'Ed Sheeran', youtubeId: 'JGwWNGJdvx8', emotion: 'neutral', thumbnail: 'https://img.youtube.com/vi/JGwWNGJdvx8/mqdefault.jpg' },
        { id: '18', title: 'Levitating', artist: 'Dua Lipa', youtubeId: 'TUVcZfQe-Kw', emotion: 'neutral', thumbnail: 'https://img.youtube.com/vi/TUVcZfQe-Kw/mqdefault.jpg' },
        { id: '19', title: 'Blinding Lights', artist: 'The Weeknd', youtubeId: 'fHI8X4OXluQ', emotion: 'neutral', thumbnail: 'https://img.youtube.com/vi/fHI8X4OXluQ/mqdefault.jpg' },
        { id: '20', title: 'Sunflower', artist: 'Post Malone', youtubeId: 'ApXoWvfEYVU', emotion: 'neutral', thumbnail: 'https://img.youtube.com/vi/ApXoWvfEYVU/mqdefault.jpg' },
      ],
      surprised: [
        { id: '21', title: 'Uptown Funk', artist: 'Bruno Mars', youtubeId: 'OPf0YbXqDm0', emotion: 'surprised', thumbnail: 'https://img.youtube.com/vi/OPf0YbXqDm0/mqdefault.jpg' },
        { id: '22', title: '24K Magic', artist: 'Bruno Mars', youtubeId: 'UqyT8IEBkvY', emotion: 'surprised', thumbnail: 'https://img.youtube.com/vi/UqyT8IEBkvY/mqdefault.jpg' },
        { id: '23', title: 'Dynamite', artist: 'BTS', youtubeId: 'gdZLi9oWNZg', emotion: 'surprised', thumbnail: 'https://img.youtube.com/vi/gdZLi9oWNZg/mqdefault.jpg' },
        { id: '24', title: 'Shake It Off', artist: 'Taylor Swift', youtubeId: 'nfWlot6h_JM', emotion: 'surprised', thumbnail: 'https://img.youtube.com/vi/nfWlot6h_JM/mqdefault.jpg' },
      ],
      fearful: [
        { id: '25', title: 'Breathe Me', artist: 'Sia', youtubeId: 'hSH7fblcGWM', emotion: 'fearful', thumbnail: 'https://img.youtube.com/vi/hSH7fblcGWM/mqdefault.jpg' },
        { id: '26', title: 'Mad World', artist: 'Gary Jules', youtubeId: '4N3N1MlvVc4', emotion: 'fearful', thumbnail: 'https://img.youtube.com/vi/4N3N1MlvVc4/mqdefault.jpg' },
        { id: '27', title: 'Hurt', artist: 'Johnny Cash', youtubeId: '8AHCfZTRGiI', emotion: 'fearful', thumbnail: 'https://img.youtube.com/vi/8AHCfZTRGiI/mqdefault.jpg' },
        { id: '28', title: 'Creep', artist: 'Radiohead', youtubeId: 'XFkzRNyygfk', emotion: 'fearful', thumbnail: 'https://img.youtube.com/vi/XFkzRNyygfk/mqdefault.jpg' },
      ],
    };

    return musicDatabase[emotion] || musicDatabase.neutral;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400">
            EmotiTune AI
          </h1>
          <p className="text-xl text-purple-200 mb-8">
            Intelligent Emotion Detection & Music Recommendation System
          </p>

          {/* Mode Toggle */}
          <div className="flex justify-center gap-4 mb-6">
            <button
              onClick={() => setDetectionMode('camera')}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                detectionMode === 'camera'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-500/50 scale-105'
                  : 'bg-white/10 hover:bg-white/20'
              }`}
            >
              📷 Camera Mode
            </button>
            <button
              onClick={() => setDetectionMode('text')}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                detectionMode === 'text'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-500/50 scale-105'
                  : 'bg-white/10 hover:bg-white/20'
              }`}
            >
              ✍️ Text Mode
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Left Panel - Emotion Detection */}
          <div className="space-y-6">
            {detectionMode === 'camera' ? (
              <EmotionDetector onEmotionDetected={handleEmotionDetected} />
            ) : (
              <TextEmotionInput onEmotionDetected={handleEmotionDetected} />
            )}
            
            <EmotionStats 
              currentEmotion={detectedEmotion} 
              emotionHistory={emotionHistory}
            />
          </div>

          {/* Right Panel - Music Recommendations */}
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-2xl">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                🎵 Recommended for: <span className="text-purple-300 capitalize">{detectedEmotion}</span>
              </h2>
              
              <div className="space-y-3 max-h-[400px] overflow-y-auto custom-scrollbar">
                {recommendedSongs.map((song) => (
                  <div
                    key={song.id}
                    onClick={() => setCurrentSong(song)}
                    className={`flex items-center gap-4 p-3 rounded-xl cursor-pointer transition-all duration-300 ${
                      currentSong?.id === song.id
                        ? 'bg-gradient-to-r from-purple-500/40 to-pink-500/40 scale-105 shadow-lg'
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <img
                      src={song.thumbnail}
                      alt={song.title}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{song.title}</h3>
                      <p className="text-sm text-purple-200">{song.artist}</p>
                    </div>
                    {currentSong?.id === song.id && (
                      <div className="flex gap-1">
                        <div className="w-1 h-4 bg-purple-400 rounded animate-pulse"></div>
                        <div className="w-1 h-4 bg-pink-400 rounded animate-pulse delay-100"></div>
                        <div className="w-1 h-4 bg-blue-400 rounded animate-pulse delay-200"></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Music Player */}
            {currentSong && <MusicPlayer song={currentSong} />}
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(168, 85, 247, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(168, 85, 247, 0.7);
        }
        .delay-100 {
          animation-delay: 0.1s;
        }
        .delay-200 {
          animation-delay: 0.2s;
        }
        .delay-1000 {
          animation-delay: 1s;
        }
        .delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </div>
  );
}
